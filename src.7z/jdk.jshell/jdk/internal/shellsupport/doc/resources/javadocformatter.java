package jdk.internal.shellsupport.doc.resources;

public final class javadocformatter extends java.util.ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "CAP_Parameters", "Parameters:" },
            { "CAP_Returns", "Returns:" },
            { "CAP_Thrown_Exceptions", "Thrown Exceptions:" },
            { "CAP_TypeParameters", "Type Parameters:" },
            { "Inline_Returns", "Returns {0}." },
        };
    }
}
