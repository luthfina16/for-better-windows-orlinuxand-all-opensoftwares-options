package jdk.jshell.resources;

public final class l10n_zh_CN extends java.util.ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "jshell.diag.modifier.plural.fatal", "\u4E0D\u5141\u8BB8\u4F7F\u7528\u4FEE\u9970\u7B26 {0}" },
            { "jshell.diag.modifier.plural.ignore", "\u4E0D\u5141\u8BB8\u4F7F\u7528\u4FEE\u9970\u7B26 {0}\uFF0C\u5DF2\u5FFD\u7565" },
            { "jshell.diag.modifier.single.fatal", "\u4E0D\u5141\u8BB8\u4F7F\u7528\u4FEE\u9970\u7B26 {0}" },
            { "jshell.diag.modifier.single.ignore", "\u4E0D\u5141\u8BB8\u4F7F\u7528\u4FEE\u9970\u7B26 {0}\uFF0C\u5DF2\u5FFD\u7565" },
            { "jshell.diag.object.method.fatal", "JShell \u65B9\u6CD5\u540D\u79F0\u4E0D\u80FD\u4E0E Object \u65B9\u6CD5\u5339\u914D: {0}" },
            { "jshell.exc.alien", "\u7247\u6BB5\u5E76\u975E\u6765\u81EA\u4E8E\u6B64 JShell: {0}" },
            { "jshell.exc.closed", "JShell ({0}) \u5DF2\u5173\u95ED\u3002" },
            { "jshell.exc.null", "\u7247\u6BB5\u4E0D\u80FD\u4E3A\u7A7A\u503C" },
            { "jshell.exc.var.not.valid", "varValue() {0} \u7684\u7247\u6BB5\u53C2\u6570\u5FC5\u987B\u4E3A VALID, \u8BE5\u53C2\u6570\u4E3A: {1}" },
        };
    }
}
