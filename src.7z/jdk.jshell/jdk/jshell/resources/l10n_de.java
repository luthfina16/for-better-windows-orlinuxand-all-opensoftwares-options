package jdk.jshell.resources;

public final class l10n_de extends java.util.ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "jshell.diag.modifier.plural.fatal", "Modifikatoren {0} nicht zul\u00E4ssig" },
            { "jshell.diag.modifier.plural.ignore", "Modifikatoren {0} nicht zul\u00E4ssig, ignoriert" },
            { "jshell.diag.modifier.single.fatal", "Modifikator {0} nicht zul\u00E4ssig" },
            { "jshell.diag.modifier.single.ignore", "Modifikator {0} nicht zul\u00E4ssig, ignoriert" },
            { "jshell.diag.object.method.fatal", "JShell-Methodennamen d\u00FCrfen nicht mit Objektmethoden \u00FCbereinstimmen: {0}" },
            { "jshell.exc.alien", "Snippet stammt nicht aus dieser JShell-Instanz: {0}" },
            { "jshell.exc.closed", "JShell ({0}) wurde geschlossen." },
            { "jshell.exc.null", "Snippet darf nicht Null sein" },
            { "jshell.exc.var.not.valid", "Snippet-Parameter von varValue() {0} muss g\u00FCltig (VALID) sein. Er lautet: {1}" },
        };
    }
}
