package jdk.jshell.resources;

public final class l10n_ja extends java.util.ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "jshell.diag.modifier.plural.fatal", "\u4FEE\u98FE\u5B50{0}\u306F\u4F7F\u7528\u3067\u304D\u307E\u305B\u3093" },
            { "jshell.diag.modifier.plural.ignore", "\u4FEE\u98FE\u5B50{0}\u306F\u4F7F\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u7121\u8996\u3055\u308C\u307E\u3059" },
            { "jshell.diag.modifier.single.fatal", "\u4FEE\u98FE\u5B50{0}\u306F\u4F7F\u7528\u3067\u304D\u307E\u305B\u3093" },
            { "jshell.diag.modifier.single.ignore", "\u4FEE\u98FE\u5B50{0}\u306F\u4F7F\u7528\u3067\u304D\u307E\u305B\u3093\u3002\u7121\u8996\u3055\u308C\u307E\u3059" },
            { "jshell.diag.object.method.fatal", "JShell\u30E1\u30BD\u30C3\u30C9\u540D\u3092\u30AA\u30D6\u30B8\u30A7\u30AF\u30C8\u30FB\u30E1\u30BD\u30C3\u30C9\u3068\u540C\u4E00\u306B\u3059\u308B\u3053\u3068\u306F\u3067\u304D\u307E\u305B\u3093: {0}" },
            { "jshell.exc.alien", "\u3053\u306EJShell\u304B\u3089\u306E\u30B9\u30CB\u30DA\u30C3\u30C8\u3067\u306F\u3042\u308A\u307E\u305B\u3093: {0}" },
            { "jshell.exc.closed", "JShell ({0})\u306F\u30AF\u30ED\u30FC\u30BA\u3055\u308C\u307E\u3057\u305F\u3002" },
            { "jshell.exc.null", "\u30B9\u30CB\u30DA\u30C3\u30C8\u306Fnull\u306B\u3067\u304D\u307E\u305B\u3093" },
            { "jshell.exc.var.not.valid", "varValue() {0}\u306E\u30B9\u30CB\u30DA\u30C3\u30C8\u30FB\u30D1\u30E9\u30E1\u30FC\u30BF\u306FVALID\u306B\u3059\u308B\u5FC5\u8981\u304C\u3042\u308A\u307E\u3059\u304C\u3001{1}\u3067\u3059" },
        };
    }
}
