package jdk.javadoc.internal.tool.resources;

public final class version extends java.util.ListResourceBundle {
    protected final Object[][] getContents() {
        return new Object[][] {
            { "full", "24+36-3646" },
            { "jdk", "24" },
            { "release", "24" },
        };
    }
}
